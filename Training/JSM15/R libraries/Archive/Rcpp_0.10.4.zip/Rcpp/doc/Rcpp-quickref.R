### R code from vignette source 'Rcpp-quickref.Rnw'

###################################################
### code chunk number 1: Rcpp-quickref.Rnw:19-22
###################################################
options( width= 50)
library( "Rcpp" )
rcpp.version <- packageDescription( "Rcpp" )$Version


